from moospread.tasks.dtlz_torch import DTLZ, DTLZ2, DTLZ4, DTLZ7
from moospread.tasks.zdt_torch import ZDT, ZDT1, ZDT2, ZDT3
from moospread.tasks.re_torch import RE21, RE33, RE34, RE37, RE41
from moospread.tasks.bo_torch import BraninCurrin, Penicillin, VehicleSafety
from moospread.tasks.mw_torch import MW7
