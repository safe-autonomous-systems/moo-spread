from moospread.utils.mobo_utils.mobo.solver.solver import Solver
from moospread.utils.mobo_utils.mobo.solver.nsga2 import NSGA2Solver
from moospread.utils.mobo_utils.mobo.solver.moead import MOEADSolver
from moospread.utils.mobo_utils.mobo.solver.pareto_discovery import ParetoDiscoverySolver
from moospread.utils.mobo_utils.mobo.solver.parego import ParEGOSolver